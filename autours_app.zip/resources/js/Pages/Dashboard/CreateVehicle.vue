<template>
    <div class="formbold-main-wrapper">
  
        <form @submit.prevent="upload">
            <div class="formbold-mb-3">
                <img v-if="photo" :src="'img/vehicles' + photo"  style="width:300px;">
                <label class="formbold-form-label">
                    Vehicle Photo
                </label>
                <input @change="handle" type="file"
                    class="formbold-form-input formbold-form-file" />
            </div>
  
            <div class="formbold-mb-3">
                <label class="formbold-form-label"> Vehicle Name </label>
                <input v-model="name" type="text" class="formbold-form-input"
                    required />
            </div>
  
            <div class="formbold-mb-3">
                <label class="formbold-form-label">Price</label>
                <div class="input-with-percent">
                  <input v-model="price" type="number" class="formbold-form-input" />
                  <span class="percent-symbol">$</span>
                </div>
            </div>

            <div class="formbold-mb-3">
                <label class="formbold-form-label">3 - 7 Days Price</label>
                <div class="input-with-percent">
                  <input v-model="weekPrice" type="number" class="formbold-form-input" />
                  <span class="percent-symbol">$</span>
                </div>
            </div>

            <div class="formbold-mb-3">
                <label class="formbold-form-label">30 Days Price</label>
                <div class="input-with-percent">
                  <input v-model="monthPrice" type="number" class="formbold-form-input" />
                  <span class="percent-symbol">$</span>
                </div>
            </div>

            <div class="formbold-mb-3">
                <label class="formbold-form-label">360 Day Price</label>
                <div class="input-with-percent">
                  <input v-model="yearPrice" type="number" class="formbold-form-input" />
                  <span class="percent-symbol">$</span>
                </div>
            </div>

            <div class="formbold-mb-3">
                <label class="formbold-form-label">Pickup Location</label>
                <div class="countries">
                    <el-select
                        v-model="country"
                        size="large"
                        filterable
                        remote
                        reserve-keyword
                        placeholder="Pickup..."
                        remote-show-suffix
                        :remote-method="remoteCountries"
                        :loading="countries.loading.value"
                    >
                        <el-option
                        v-for="item in countries.options.value"
                        :key="item.id"
                        :label="item.label"
                        :value="item.label"
                        @click="fetchStates(item.iso)"
                        />
                    </el-select>

                    <el-select
                        v-model="state"
                        size="large"
                        filterable
                        remote
                        reserve-keyword
                        placeholder="Pickup..."
                        remote-show-suffix
                        :remote-method="remoteStates"
                        :loading="states.loading.value"
                    >
                        <el-option
                        v-for="item in states.options.value"
                        :key="item.id"
                        :label="item.label"
                        :value="item.label"
                        />
                    </el-select>
                </div>
            </div>
            <!-- <div class="formbold-mb-3">
                <label class="formbold-form-label">Date</label>
                <el-date-picker
                    v-model="date"
                    type="daterange"
                    range-separator="To"
                    start-placeholder="Start date"
                    end-placeholder="End date"
                    size="large"
                    format="YYYY/MM/DD"
                    value-format="YYYY-MM-DD"
                    />
            </div> -->
            <div class="formbold-mb-3">
                <label class="formbold-form-label">Category</label>
                    <el-select
                        v-model="category"
                        size="large"
                        filterable
                        remote
                        reserve-keyword
                        placeholder="Pickup..."
                        remote-show-suffix
                        :remote-method="remoteCategories"
                        :loading="categories.loading.value"
                        @click="remoteCategories()"
                    >
                        <el-option
                        v-for="item in categories.options.value"
                        :key="item.id"
                        :label="item.label"
                        :value="item.id"
                        />
                    </el-select>
            </div>

            <div v-for="(list, i) in specifications" :key="i" class="formbold-mb-3">
                <label class="formbold-form-label">{{list.name}}</label>
                    <el-select
                        v-model="specification[i]"
                        size="large"
                        filterable
                        remote
                        reserve-keyword
                        placeholder="Pickup..."
                        remote-show-suffix
                    >
                        <el-option
                        v-for="item in list.options"
                        @click="getSpecificationOption(list.name, item)"
                        :key="item"
                        :label="item"
                        :value="item"
                        />
                    </el-select>
            </div>

            <div class="text-center">
                <button type="submit" class="formbold-btn">Submit</button>
            </div>
        </form>
    </div>
  </template>
  
<script setup>
import { onMounted, ref } from 'vue'

const photo = ref('')
const image = ref('')
const name = ref('')
const price = ref('')
const weekPrice = ref('')
const monthPrice = ref('')
const yearPrice = ref('')
const country = ref('')
const state = ref('')
const countries = {
loading: ref(false),
all:ref([]),
list: ref([]),
options: ref([]),
};
const states = {
loading: ref(false),
all:ref([]),
list: ref([]),
options: ref([]),
};

const category = ref('')
const categories = {
loading: ref(false),
all:ref([]),
list: ref([]),
options: ref([]),
};

const specification  = ref([])
const specifications  = ref([])
const selectedSpecifications = ref([])


const getSpecificationOption = (name, option) => {
  const s = {
    'name': name,
    'option': option,
  }
  
  const isDuplicate = selectedSpecifications.value.some(item => (
    item.name === name
  ));

  if (!isDuplicate) {
    selectedSpecifications.value.push(s);
  } else {
    const existingItem = selectedSpecifications.value.find(item => item.name === name);
    if (existingItem) {
      existingItem.option = option;
  }
}
};

const fetchSpecifications = async () => {
  try {
    const response = await axios.get('get/specifications');
    specifications.value = response.data;
  } catch (error) {
    console.error(error);
  } finally {
    
  }
}

const fetchCategories = async () => {
    categories.loading.value = true;
    try {
        const response = await axios.get('get/categories')
        categories.all.value = response.data
        categories.list.value = categories.all.value.map((item) => ({
        id: `${item.id}`,
        label: `${item.name}`,
        }))   
    } catch (error) {
        console.error(error)
    } finally {
        categories.loading.value = false;
    }
}

const remoteCategories = (query) => {
  if (query) {
    categories.loading.value = true
    setTimeout(() => {
      categories.loading.value = false
      categories.options.value = categories.list.value.filter((item) =>
        item.label.toLowerCase().includes(query.toLowerCase())
      )
    }, 200)
  } else {
    categories.options.value = categories.list.value;
  }
}

const fetchCountries = async () => {
    countries.loading.value = true;
    try {
        const response = await axios.get('https://api.countrystatecity.in/v1/countries', {
        headers: {
            'X-CSCAPI-KEY': 'NVZhakViaFdtOXBJZ0xoQW1lWkJGTmlGUW1Kb05XaElGbXhocnNNOA=='
        }
        })
        countries.all.value = response.data
        countries.list.value = countries.all.value.map((item) => ({
        id: `${item.id}`,
        label: `${item.name}`,
        iso: `${item.iso2}`
        }))   
    } catch (error) {
        console.error(error)
    } finally {
        countries.loading.value = false;
    }
}

const fetchStates = async (iso) => {
    states.loading.value = true
    try {
        const response = await axios.get(`https://api.countrystatecity.in/v1/countries/${iso}/states`, {
        headers: {
            'X-CSCAPI-KEY': 'NVZhakViaFdtOXBJZ0xoQW1lWkJGTmlGUW1Kb05XaElGbXhocnNNOA=='
        }
        })
        states.all.value = response.data
        states.list.value = states.all.value.map((item) => ({
        value: `${item.id}`,
        label: `${item.name}`,
        }))
    } catch (error) {
        console.error(error)
    } finally {
        states.loading.value = false
    }
}

const remoteCountries = (query) => {
  if (query) {
    countries.loading.value = true
    setTimeout(() => {
      countries.loading.value = false
      countries.options.value = countries.list.value.filter((item) =>
        item.label.toLowerCase().includes(query.toLowerCase())
      )
    }, 200)
  } else {
    countries.options.value = []
  }
}

const remoteStates = (query) => {
  if (query) {
    states.loading.value = true
    setTimeout(() => {
        states.loading.value = false
        states.options.value = states.list.value.filter((item) =>
        item.label.toLowerCase().includes(query.toLowerCase())
      )
    }, 200)
  } else {
    states.options.value = []
  }
}
  
  const handle = (event) => {
    image.value = event.target.files[0]
  }
  
  const upload = async () => {
    try {
        const formData = new FormData();
        formData.append('photo', image.value);
        formData.append('name', name.value);
        formData.append('price', price.value);
        formData.append('week_price', weekPrice.value);
        formData.append('month_price', monthPrice.value);
        formData.append('year_price', yearPrice.value);
        formData.append('pickupLoc', `${country.value}, ${state.value}`);
        formData.append('category', category.value);
        formData.append('specifications', JSON.stringify(selectedSpecifications.value));
        const response = await axios.post('post/vehicles', formData);
        console.log(response.data)
    } catch (error) {
      console.error(error);
    } finally {
        photo.value = null;
        image.value = null;
        name.value = null;
        price.value = null;
        weekPrice.value = null;
        monthPrice.value = null;
        country.value = null;
        state.value = null;
        category.value = null;
    }
  }
  
  
  onMounted(() => {
    fetchCountries();
    fetchCategories();
    fetchSpecifications();
  });
  </script>