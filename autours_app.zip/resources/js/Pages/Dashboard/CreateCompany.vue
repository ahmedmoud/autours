<template>
  <h2 class="mb-4">My Profile</h2>
  <div class="formbold-main-wrapper">
      <form @submit.prevent="upload">
          <div v-if="supplier || activeSupplier || reviewing" class="formbold-mb-3">
              <label class="formbold-form-label">
                  Company Logo
              </label>
              <input @change="handle" type="file"
                  class="formbold-form-input formbold-form-file" />
          </div>

          <div v-if="supplier || activeSupplier || reviewing || admin" class="formbold-mb-3">
              <label class="formbold-form-label"> Company Name </label>
              <input v-model="company" type="text" class="formbold-form-input"
                  required />
          </div>

          <div class="formbold-mb-3">
              <label class="formbold-form-label"> User Name </label>
              <input v-model="name" class="formbold-form-input"
                    required />
          </div>

          <div class="formbold-mb-3">
              <label class="formbold-form-label"> Email </label>
              <input v-model="email" class="formbold-form-input disabled"
                    required disabled/>
          </div>

          <div class="formbold-mb-3">
              <label class="formbold-form-label"> Phone </label>
              <input v-model="phone" type="number" class="formbold-form-input"
                    required />
          </div>

          <div v-if="supplier || activeSupplier || reviewing" class="formbold-mb-3">
              <label class="formbold-form-label">Address</label>
              <textarea v-model="address" class="form-control" rows="3"></textarea>
          </div>

          <div class="formbold-mb-3">
              <label class="formbold-form-label"> Old Password </label>
              <input v-model="oldPass" type="password" class="formbold-form-input"
                    required />
          </div>

          <div class="formbold-mb-3">
              <label class="formbold-form-label"> New Password </label>
              <input v-model="newPass" type="password" class="formbold-form-input"
                     />
          </div>

          <div class="formbold-mb-3">
              <label class="formbold-form-label"> Confirm Password </label>
              <input v-model="confirmNewPass" type="password" class="formbold-form-input"
                     />
          </div>

          <div class="text-center">
              <button type="submit" class="formbold-btn">Submit</button>
          </div>
      </form>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'

const logo = ref('');
const image = ref('');
const name = ref('');
const email = ref('');
const phone = ref('');
const oldPass = ref('');
const newPass = ref('');
const confirmNewPass = ref('');
const company = ref(''); 
const address = ref('');
const role = ref('')
const admin = ref(false)
const activeSupplier = ref(false)
const supplier = ref(false)
const customer = ref(false)
const reviewing = ref(false)
const formStatus = ref(true)

const open = () => {
  if(formStatus.value === true){
    ElMessage({
      showClose: true,
      message: 'Updated successfully.',
      type: 'success',
    })
  } else{
    ElMessage.error('Oops, wrong password.')
  }
}

const getRole = async () => {
    try{
        const response = await axios.get('get/user/role');
        role.value = response.data;
    } catch (error) {
        console.error(error);
    } finally {
        if (role.value === 'admin') {
            admin.value = true
        } else if (role.value === 'active_supplier') {
            activeSupplier.value = true
        } else if (role.value === 'supplier') {
            supplier.value = true
        } else if (role.value === 'customer') {
            customer.value = true
        } else if (role.value === 'reviewing') {
            reviewing.value = true
        }
    }
}

const handle = (event) => {
  image.value = event.target.files[0]
}

const getUserData = async () => {
  try {
    const response = await axios.get('/get/user/data');
    logo.value = response.data.logo ? response.data.logo : '';
    name.value = response.data.name ? response.data.name : '';
    email.value = response.data.email ? response.data.email : '';
    phone.value = response.data.phone_num ? response.data.phone_num : '';
    company.value = response.data.company ? response.data.company : '';
    address.value = response.data.address ? response.data.address : '';
  } catch (error) {
    console.error(error);
  }
}

const upload = async () => {
  const formData = new FormData();
  if (image.value) {
    formData.append('logo', image.value);
  }
  if (name.value) {
    formData.append('name', name.value);
  }
  if (email.value) {
    formData.append('email', email.value);
  }
  if (phone.value) {
    formData.append('phone', phone.value);
  }
  if (oldPass.value) {
    formData.append('oldPass', oldPass.value);
  }
  if (newPass.value) {
    formData.append('newPass', newPass.value);
  }
  if (confirmNewPass.value) {
    formData.append('confirmNewPass', confirmNewPass.value);
  }
  if (company.value) {
    formData.append('company', company.value);
  }
  if (address.value) {
    formData.append('address', address.value);
  }
  try {
    const response = await axios.post('upload', formData);
    if(response.data.message === 0){
      formStatus.value = false;
    } else {
      formStatus.value = true;
    }
    open();
    getUserData();
  } catch (error) {
    console.error(error);
  } finally {
    oldPass.value = null;
    newPass.value = null;
    confirmNewPass.value = null;
  }
}

onMounted(() => {
  getUserData();
  getRole();
});

</script>

<style>
.formbold-form-input.disabled{
  background: rgba(128, 128, 128,0.1);
  color: rgba(0, 0, 0,0.3);
}
</style>